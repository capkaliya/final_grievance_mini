package com.cybage.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.cybage.dao.CitizenDao;
import com.cybage.model.Citizen;
import com.cybage.model.Complaint;

public class CitizenServiceImpl implements iCitizenService {
	
	private String generateCompID(){
		return "G"+ Math.round(Math.random()*999999999);
	}
	
	private LocalDateTime dateTime() {
		 LocalDateTime today = LocalDateTime.now();
		 return today;
	}
	CitizenDao citiznDao = new CitizenDao();
	
	
	public String generateCustID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	
	public int addCitizen(Citizen citizn) throws Exception{
		return citiznDao.addCitizen(generateCustID(),citizn);
	}
	
	
	public int addComplain(Complaint comp) throws Exception {
		LocalDate today = LocalDate.now();
		System.out.println(today);
		System.out.println(comp.getUsername());
		Complaint compln = new Complaint(generateCompID(),comp.getUsername() , comp.getDeptId(), comp.getDescription(), comp.getStatus(), comp.getFile(), today);
		System.out.println("in service");
		citiznDao.addComplain(compln);
		return 0;
	}
	

	public List<Complaint> getStatus(String CitizId) throws Exception {
		
		return citiznDao.getStatus(CitizId);
	}
	
	public int setReminder(String compId) throws Exception {
		Complaint remind = new Complaint(compId, dateTime());
		return citiznDao.setReminder(remind);
	}
	
	public int reOpen(String compId) throws Exception {
		return citiznDao.reOpen(compId);
		
	}

	public String getCitizenId(String username) throws Exception {
		return citiznDao.getCitizenId(username);
	}
	public LocalDate getComplainDate(String compId) throws Exception {
		LocalDate localDate = LocalDate.parse(citiznDao.getDate(compId));
		return localDate ;
	}

}
