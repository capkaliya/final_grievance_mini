package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Citizen;
import com.cybage.model.Complaint;

public class CitizenDao {

	public int addComplain(Complaint comp) throws Exception {
		String sql = "insert into complaint values(?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		String deptId = getDeptId(comp.getDeptId());
		ps.setString(1, comp.getCompId());
		ps.setString(2, getCitizenId(comp.getCitizenName()));
		ps.setString(3, getDeptId(comp.getDeptName()));
		ps.setString(4, comp.getDescription());
		ps.setString(5, comp.getStatus());
		ps.setString(6, comp.getFile());
		ps.setDate(7, java.sql.Date.valueOf(comp.getDate()));
		ps.setString(8, "");
		System.out.println("value added");
		return ps.executeUpdate();
	}

	//For getting DeptId
	public String getDeptId(String name) throws Exception{
		String sql = "select deptId from department where departmentname = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();
		String  deptId = null;
		if(rs.next()) {
			deptId = rs.getString(1);
		}
		return deptId;
	}

	//For getting complaint status

	public List<Complaint> getStatus(String citizId) throws Exception{
		String sql = "SELECT complaint.compId, complaint.status, complaint.remark,complaint.date, "
				+ "citizen.name FROM complaint "
				+ "INNER JOIN citizen ON complaint.citizenId=citizen.citizenId where citizen.citizenId = ?";

		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, citizId);
		ResultSet rs = ps.executeQuery();

		List<Complaint> status = new ArrayList<Complaint>();
		while(rs.next()) {
			status.add(new Complaint(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(5),rs.getDate(4).toLocalDate()));
		}
		System.out.println(status);
		return status;
	}
	public int setReminder(Complaint remind)  throws Exception{
		String sql = "insert into reminder (complainId,date) values(?, ?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
		//		ps.setString(1, "1");
		ps.setString(1, remind.getCompId());
		System.out.println("In reminder DAO");
		System.out.println(remind.getCompId());
		
		ps.setTimestamp(2, java.sql.Timestamp.valueOf(remind.getDatetime()));
		return ps.executeUpdate();
	}

	// Reopening Complain
	public int reOpen(String compId)  throws Exception{
		String sql = "update complaint set status = ? where compId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, "ReOpen");
		ps.setString(2, compId);
		return ps.executeUpdate();
	}

	//CITIZEN REGISTER

	public int addCitizen(String cid,Citizen citizn) throws Exception {



		String sql1="insert into user(username,password,role) values(?,?,?)";
		Connection connection1 = DbUtil.getConnection();
		PreparedStatement ps1 = connection1.prepareStatement(sql1,Statement.RETURN_GENERATED_KEYS);
		//System.out.println(cid);
		//ps1.setString(1, cid);

		ps1.setString(1, citizn.getUsername());
		ps1.setString(2, citizn.getPassword());
		ps1.setString(3, citizn.getRole());
		//ps1.setString(4, cid);
		ps1.executeUpdate();
		int userid=0;
		ResultSet generatedKeys = ps1.getGeneratedKeys();
		if (generatedKeys.next()) {
			userid=(int) generatedKeys.getLong(1);
		}



		String sql = "insert into citizen(citizenid,name,address,contact,userId) values(?, ?, ?, ?,?)";
		//String sql1="insert into user values(?,?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		//System.out.println(cid);
		ps.setString(1, cid);
		ps.setString(2, citizn.getname());
		ps.setString(3, citizn.getAddress());
		ps.setString(4, citizn.getContact());
		ps.setInt(5, userid);
		//ps.executeUpdate();
		return ps.executeUpdate();
		//ps.setString(2, citizn.getUsername());
		//ps.setString(3,citizn.getPassword()); 
	}

	public String getCitizenId(String username) throws Exception {
		String sql = "select c.citizenId from citizen c inner join user u on c.userId=u.userId where username = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, username);
		ResultSet rs = ps.executeQuery();
		String  deptId = null;
		if(rs.next()) {
			deptId = rs.getString(1);
		}
		System.out.println(deptId);
		return deptId;
	}
	//For getting  DATE
		public String getDate(String compId) throws Exception{
			String sql = "select date from complaint where compId = ?";
			Connection connection = DbUtil.getConnection();
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, compId);
			ResultSet rs = ps.executeQuery();
			String  date = null;
			if(rs.next()) {
				date = rs.getString(1);
			}
			return date;
		}

}
