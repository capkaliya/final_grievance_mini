package com.cybage.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.cybage.model.Citizen;
import com.cybage.model.Complaint;
import com.cybage.service.CitizenServiceImpl;
import com.cybage.service.iCitizenService;
import com.mysql.cj.Session;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
maxFileSize = 1024 * 1024 * 1000, // 1 GB
maxRequestSize = 1024 * 1024 * 1000)   	// 1 GB
public class CitizenController extends HttpServlet {

	iCitizenService citiznService = new CitizenServiceImpl() ;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String username=(String) session.getAttribute("username");
		System.out.println(username);
		String cid;
		System.out.println("citizen");
		String path = request.getPathInfo();
		System.out.println(path);


		if(path.equals("/citizenHome")) {



			try {
				cid = citiznService.getCitizenId(username);

				session = request.getSession();
				session.setAttribute("cid", cid);
				request.getRequestDispatcher("/citizen/citizen-home.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// Register Complain
		if(path.equals("/complain")) {	
			System.out.println("In controller");
			try {

				//				request.getServletContext().getRealPath("/")				
				String folderName = "Images";
				String uploadPath =  "D:\\core_mini_project\\Grievance\\src\\main\\webapp\\"+ folderName ;
				System.out.println(uploadPath);
				File dir = new File(uploadPath);
				if (!dir.exists()) {
					dir.mkdirs();
				}
				Part filePart = request.getPart("file");
				String fullPath = filePart.getSubmittedFileName();
				String fileName = fullPath.substring(fullPath.lastIndexOf("\\")+1);
				//	            String filepath = folderName + File.separator + fileName;
				uploadPath = uploadPath + File.separator + fileName; 
				//	            Timestamp added_date = new Timestamp(System.currentTimeMillis());
				System.out.println("fileName: " + fileName);
				System.out.println("Path: " + uploadPath);

				InputStream is = filePart.getInputStream();
				Files.copy(is, Paths.get(uploadPath), StandardCopyOption.REPLACE_EXISTING);
				Complaint citiz = new Complaint();
				citiz.setUsername(username);

				citiz.setDeptId(request.getParameter("grievance").toLowerCase());
				System.out.println("WATER");
				System.out.println(citiz.getDeptId());
				citiz.setDescription(request.getParameter("desc"));
				citiz.setFile(uploadPath);
				citiz.setStatus("Active");
				System.out.println("controller");
				citiznService.addComplain(citiz);
				request.getRequestDispatcher("/citizen/success-complain.jsp").forward(request, response);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		//View Status
		if(path.equals("/ViewStatus")) {



			try {
				session = request.getSession();
				cid = (String) session.getAttribute("cid");
				List<Complaint> statusList =  citiznService.getStatus(cid);
				request.setAttribute("status", statusList);
				request.getRequestDispatcher("/citizen/view-status.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		//Setting Reminder
		if(path.equals("/reminder")) {			
			try {
				cid = citiznService.getCitizenId(username);
				List<Complaint> statusList =  citiznService.getStatus(cid);
				LocalDate date = citiznService.getComplainDate(request.getParameter("compId"));
				LocalDate from = date;
				LocalDate to = LocalDate.now();
				Period period = Period.between(from, to);
				if(period.getDays()>7) {
					int id =citiznService.setReminder(request.getParameter("compId"));
					request.setAttribute("remind", id);
					request.setAttribute("status", statusList);
					request.setAttribute("msg", "Reminder Given To Concerned Department");
					request.getRequestDispatcher("/citizen/view-status.jsp").forward(request, response);

				}
				else {
					request.setAttribute("remind",0);
					request.setAttribute("status", statusList);
					request.setAttribute("msg", "Wait For Minimum 7 Days");
					request.getRequestDispatcher("/citizen/view-status.jsp").forward(request, response);


				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/reopen")) {			
			try {
				List<Complaint> statusList =  citiznService.getStatus(request.getParameter("citizenId"));

				int id =citiznService.reOpen(request.getParameter("compId"));

				request.setAttribute("status", statusList);

				request.getRequestDispatcher("/citizen/view-status.jsp").forward(request, response);

			}catch (Exception e) {
				e.printStackTrace();
			}

		}

		//Citizen Controller

		if(path.equals("/registercitizen")) {		
			System.out.println("inside citizen controller");
			try {
				Citizen citizn = new Citizen();
				citizn.setname(request.getParameter("name"));
				citizn.setUsername(request.getParameter("username"));
				citizn.setPassword(request.getParameter("password"));
				citizn.setAddress(request.getParameter("address"));
				citizn.setContact(request.getParameter("contact"));
				citizn.setRole(request.getParameter("role"));

				citiznService.addCitizen(citizn);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				//response.sendRedirect("listcitizen");								
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}





	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
