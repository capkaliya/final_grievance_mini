function validateform()
 { 
	     
	    var name = document.forms["RegForm"]["name"]; 
	    var username =document.forms["RegForm"]["username"];
        var phone = document.forms["RegForm"]["contact"]; 
        var password = document.forms["RegForm"]["password"]; 
        var address = document.forms["RegForm"]["address"]; 
        var regex = /^[6-9]{1}[0-9]{9}$/; 
        var regex1=/[a-zA-Z]+/;
        if (regex1.test(name.value) == false) { 
            window.alert("Please Enter Alphabets Only"); 
            name.focus(); 
            return false; 
        } 
        if (name.value == "") { 
            window.alert("Please Enter Your Name"); 
            name.focus(); 
            return false; 
        } 
         if (username.value == "") { 
            window.alert("Please Enter Your Username"); 
            password.focus(); 
            return false; 
        }
        
        if (password.value == "") { 
            window.alert("Please Enter Your Password"); 
            password.focus(); 
            return false; 
        } 
        
        if(password.value.length == '' || password.value.length >12 || password.value.length <8)
        {
		alert("Password should be between 8-12");
		password.focus();
		return false;
	    } 
	
	
	    if(!password.value.match(confirm_password.value))
	    {
		//alert("Password not matching");
		confirm_password.focus();
		return false;
	    }
        
  
        if (address.value == "") { 
            window.alert("Please enter your address"); 
            address.focus(); 
            return false; 
        } 
  
        if (regex.test(phone.value )== false) { 
            window.alert("Please enter your 10 mobile number"); 
            phone.focus(); 
            return false; 
        } 
        return true; 
 } 
 
 
$(document).ready(function(){
    $('#pwd, #cpwd').on('keyup',function()
    {
       if($('#pwd').val() == $('#cpwd').val())
       {
           $('#message').html('Matching').css('color','green');
       }else
           $('#message').html('Not Matching').css('color','red');
    });
})
